/*************************************************************************************
@company: WHEELTEC (Dongguan) Co., Ltd
@product: M2 / M2N / M07
@filename: com.cpp
@brief: 统一串口设备管理（支持M2、M2N、M07）
@version:       date:       author:            comments:
@v2.0           26-6-1      hj
*************************************************************************************/
#include "com.h"
#include "m2n_com.h"
#include "m07_com.h"

// 全局串口对象
SerialPort g_serial_port;

// M2协议常量
#define FRAME_HEADER_M2      0XA5
#define USER_ID_M2           0X01

// ==================== SerialPort 类实现 ====================

SerialPort::SerialPort() 
    : device_type_(getConfiguredDeviceType())
    , if_awake_(false)
    , angle_int_(0)
    , initialized_(false)
    , control_fd_(-1)
    , audio_fd_(-1) {
    receive_data_.resize(1024, 0);
}

SerialPort::~SerialPort() {
    deinit();
}

bool SerialPort::init(DeviceType type, const std::string& control_port) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (initialized_) {
        deinit();
    }
    
    device_type_ = type;
    if_awake_ = false;
    angle_int_ = 0;
    
    bool result = false;
    
    switch (device_type_) {
        case DeviceType::DEVICE_M2:
            result = openPort(control_port);
            if (result) {
                result = setOpt(115200, 8, 'N', 1);
            }
            break;
            
        case DeviceType::DEVICE_M2N: {
            m2n_config_.control_port = control_port;
            result = M2NManager::getInstance().init(m2n_config_);
            if (result) {
                control_fd_ = M2NManager::getInstance().getControlFd();
                audio_fd_ = M2NManager::getInstance().getAudioFd();
            }
            break;
        }
        
        case DeviceType::DEVICE_M07:
            result = M07Manager::getInstance().init(control_port, 115200);
            if (result) {
                control_fd_ = M07Manager::getInstance().getSerialFd();
            }
            break;
    }
    
    initialized_ = result;
    
    return result;
}

void SerialPort::deinit() {
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (!initialized_) {
        return;
    }
    
    switch (device_type_) {
        case DeviceType::DEVICE_M2:
            closePort();
            break;
            
        case DeviceType::DEVICE_M2N:
            M2NManager::getInstance().deinit();
            break;
            
        case DeviceType::DEVICE_M07:
            M07Manager::getInstance().deinit();
            break;
    }
    
    control_fd_ = -1;
    audio_fd_ = -1;
    initialized_ = false;
    if_awake_ = false;
    angle_int_ = 0;
}

bool SerialPort::openPort(const std::string& uartname) {
    control_fd_ = open(uartname.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (control_fd_ == -1) {
        perror("Can't Open Serial Port");
        return false;
    }
    
    if (fcntl(control_fd_, F_SETFL, 0) < 0) {
        perror("fcntl failed");
        closePort();
        return false;
    }
    
    return true;
}

void SerialPort::closePort() {
    if (control_fd_ != -1) {
        close(control_fd_);
        control_fd_ = -1;
    }
    if (audio_fd_ != -1 && audio_fd_ != control_fd_) {
        close(audio_fd_);
        audio_fd_ = -1;
    }
}

bool SerialPort::setOpt(int nSpeed, int nBits, unsigned char nEvent, int nStop) {
    struct termios newtio, oldtio;
    
    if (tcgetattr(control_fd_, &oldtio) != 0) {
        perror("SetupSerial 1");
        return false;
    }
    
    bzero(&newtio, sizeof(newtio));
    newtio.c_cflag |= CLOCAL | CREAD;
    newtio.c_cflag &= ~CSIZE;

    switch (nBits) {
        case 7: newtio.c_cflag |= CS7; break;
        case 8: newtio.c_cflag |= CS8; break;
        default: break;
    }

    switch (nEvent) {
        case 'O':
            newtio.c_cflag |= PARENB | PARODD;
            newtio.c_iflag |= (INPCK | ISTRIP);
            break;
        case 'E':
            newtio.c_iflag |= (INPCK | ISTRIP);
            newtio.c_cflag |= PARENB;
            newtio.c_cflag &= ~PARODD;
            break;
        case 'N':
            newtio.c_cflag &= ~PARENB;
            break;
        default: break;
    }

    speed_t speed;
    switch (nSpeed) {
        case 2400: speed = B2400; break;
        case 4800: speed = B4800; break;
        case 9600: speed = B9600; break;
        case 115200: speed = B115200; break;
        case 460800: speed = B460800; break;
        case 921600: speed = B921600; break;
        default: speed = B9600; break;
    }
    cfsetispeed(&newtio, speed);
    cfsetospeed(&newtio, speed);

    if (nStop == 1) {
        newtio.c_cflag &= ~CSTOPB;
    } else if (nStop == 2) {
        newtio.c_cflag |= CSTOPB;
    }
    
    newtio.c_cc[VTIME] = 0;
    newtio.c_cc[VMIN] = 0;
    
    tcflush(control_fd_, TCIFLUSH);
    if (tcsetattr(control_fd_, TCSANOW, &newtio) != 0) {
        perror("com set error");
        return false;
    }
    
    return true;
}

int SerialPort::readData(std::vector<unsigned char>& buffer) {
    if (control_fd_ == -1) return -1;
    
    buffer.resize(1024);
    int n = read(control_fd_, buffer.data(), buffer.size());
    if (n > 0) {
        buffer.resize(n);
    } else {
        buffer.clear();
    }
    return n;
}

int SerialPort::writeData(const unsigned char* data, size_t length) {
    if (control_fd_ == -1) return -1;
    return write(control_fd_, data, length);
}

int SerialPort::dealWith(unsigned char buffer) {
    int result = -1;
    
    switch (device_type_) {
        case DeviceType::DEVICE_M2:
            result = processM2Byte(buffer);
            break;
        case DeviceType::DEVICE_M2N:
            result = processM2NByte(buffer);
            break;
        case DeviceType::DEVICE_M07:
            result = processM07Byte(buffer);
            break;
    }
    
    return result;
}

// M2旧版协议处理
int SerialPort::processM2Byte(unsigned char buffer) {
    receive_data_[count_] = buffer;
    
    if (receive_data_[0] != FRAME_HEADER_M2 || (count_ == 1 && receive_data_[1] != USER_ID_M2)) {
        count_ = 0;
        frame_len_ = 0;
        msg_id_ = 0;
        return 0;
    }
    
    count_++;
    
    if (count_ == 7) {
        msg_id_ = dataTrans(receive_data_[6], receive_data_[5]);
        frame_len_ = dataTrans(receive_data_[4], receive_data_[3]) + 8;
    }
    
    if (count_ == frame_len_ && frame_len_ > 0) {
        switch (receive_data_[2]) {
            case 0x04:
                if (checkSum(frame_len_ - 1) == receive_data_[frame_len_ - 1]) {
                    if_awake_ = true;
                    
                    int json_len = frame_len_ - 8;
                    if (json_len <= 0) {
                        break;
                    }
                    
                    std::vector<char> json_data(json_len + 1, 0);
                    for (int i = 0; i < json_len; i++) {
                        json_data[i] = receive_data_[i + 7];
                    }
                    json_data[json_len] = '\0';  // 确保 null 结尾
                    
                    cJSON* json1 = cJSON_Parse(json_data.data());
                    if (json1) {
                        cJSON* content = cJSON_GetObjectItem(json1, "content");
                        if (content) {
                            cJSON* info = cJSON_GetObjectItemCaseSensitive(content, "info");
                            if (info && info->valuestring) {
                                std::string info_str = info->valuestring;
                                if (info_str.length() > 0) {
                                    cJSON* json2 = cJSON_Parse(info_str.c_str());
                                    if (json2) {
                                        cJSON* ivw = cJSON_GetObjectItem(json2, "ivw");
                                        if (ivw) {
                                            cJSON* angle = cJSON_GetObjectItem(ivw, "angle");
                                            if (angle && cJSON_IsNumber(angle)) {
                                                angle_int_ = angle->valueint;
                                                printf("[M2] Wakeup, angle=%d\n", angle_int_.load());
                                            }
                                        }
                                        cJSON_Delete(json2);
                                    }
                                }
                            }
                        }
                        cJSON_Delete(json1);
                    }
                }
                break;
            default:
                break;
        }
        
        count_ = 0;
        frame_len_ = 0;
        msg_id_ = 0;
        std::fill(receive_data_.begin(), receive_data_.end(), 0);
    }
    
    return 0;
}

// M2N协议处理
int SerialPort::processM2NByte(unsigned char buffer) {
    int ret = M2NManager::getInstance().processByte(buffer);
    
    if (M2NManager::getInstance().isAwake()) {
        if_awake_ = true;
        angle_int_ = M2NManager::getInstance().getAngle();
        M2NManager::getInstance().clearAwake();
    }
    
    return ret;
}

// M07协议处理
int SerialPort::processM07Byte(unsigned char buffer) {
    int ret = M07Manager::getInstance().processByte(buffer);
    
    return ret;
}

unsigned char SerialPort::checkSum(int count_num) {
    unsigned char sum = 0;
    for (int i = 0; i < count_num; i++) {
        sum += receive_data_[i];
    }
    return ~sum + 1;
}

short SerialPort::dataTrans(unsigned char data_high, unsigned char data_low) {
    return (static_cast<short>(data_high) << 8) | data_low;
}

bool SerialPort::isAwake() const {
    if (device_type_ == DeviceType::DEVICE_M07) {
        return M07Manager::getInstance().isAwake();
    }
    return if_awake_.load();
}

int SerialPort::getAngle() const {
    return angle_int_.load();
}

void SerialPort::resetAwake() {
    if (device_type_ == DeviceType::DEVICE_M2N) {
        M2NManager::getInstance().clearAwake();
    } else if (device_type_ == DeviceType::DEVICE_M07) {
        M07Manager::getInstance().clearAwake();
    }
    if_awake_ = false;
}

bool SerialPort::switchDevice(DeviceType new_type, const std::string& port) {
    deinit();
    return init(new_type, port.empty() ? m2n_config_.control_port : port);
}

M2NManager& SerialPort::getM2NManager() {
    return M2NManager::getInstance();
}

M07Manager& SerialPort::getM07Manager() {
    return M07Manager::getInstance();
}