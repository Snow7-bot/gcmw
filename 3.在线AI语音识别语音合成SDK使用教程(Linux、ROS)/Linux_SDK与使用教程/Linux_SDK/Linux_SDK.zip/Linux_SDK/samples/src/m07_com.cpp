/*************************************************************************************
@company: WHEELTEC (Dongguan) Co., Ltd
@product: M07
@filename: m07_com.cpp
@brief: M07 串口通信协议实现
@version:       date:       author:            comments:
@v1.0           26-6-1      hj                
*************************************************************************************/

#include "m07_com.h"

// 单例实例
M07Manager& M07Manager::getInstance() {
    static M07Manager instance;
    return instance;
}

M07Manager::M07Manager()
    : serial_fd_(-1)
    , initialized_(false)
    , debug_mode_(false)
    , state_(State::IDLE)
    , awake_flag_(false)
    , min_interval_(1.0) {
    memset(&last_awake_time_, 0, sizeof(last_awake_time_));
}

M07Manager::~M07Manager() {
    deinit();
}

double M07Manager::getTimeSeconds() {
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    return (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0;
}

void M07Manager::updateLastAwakeTime() {
    gettimeofday(&last_awake_time_, nullptr);
}

int M07Manager::openSerial(const std::string& port, int baudrate) {
    int fd = open(port.c_str(), O_RDWR | O_NOCTTY);
    if (fd < 0) {
        printf("[M07] Failed to open %s: %s\n", port.c_str(), strerror(errno));
        return -1;
    }
    
    struct termios tty;
    memset(&tty, 0, sizeof(tty));
    
    if (tcgetattr(fd, &tty) != 0) {
        printf("[M07] tcgetattr error: %s\n", strerror(errno));
        close(fd);
        return -1;
    }
    
    speed_t speed;
    switch (baudrate) {
        case 9600: speed = B9600; break;
        case 19200: speed = B19200; break;
        case 38400: speed = B38400; break;
        case 57600: speed = B57600; break;
        case 115200: speed = B115200; break;
        default: speed = B115200; break;
    }
    cfsetispeed(&tty, speed);
    cfsetospeed(&tty, speed);
    
    // 8N1 配置
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;
    tty.c_cflag &= ~CRTSCTS;
    tty.c_cflag |= CREAD | CLOCAL;
    
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    tty.c_oflag &= ~OPOST;
    
    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 10;
    
    tcflush(fd, TCIOFLUSH);
    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        printf("[M07] tcsetattr error: %s\n", strerror(errno));
        close(fd);
        return -1;
    }
    
    printf("[M07] Opened %s @ %d baud\n", port.c_str(), baudrate);
    return fd;
}

void M07Manager::closeSerial() {
    if (serial_fd_ >= 0) {
        close(serial_fd_);
        serial_fd_ = -1;
    }
}

void M07Manager::handleWakeup() {
    double now = getTimeSeconds();
    double last = (double)last_awake_time_.tv_sec + 
                  (double)last_awake_time_.tv_usec / 1000000.0;
    double interval = now - last;
    
    if (interval >= min_interval_) {
        std::lock_guard<std::mutex> lock(mutex_);
        awake_flag_ = true;
        updateLastAwakeTime();
        printf("[M07] Wakeup detected!\n");
        fflush(stdout);
    } else if (debug_mode_) {
        printf("[M07] Wakeup ignored (%.2fs < %.2fs)\n", interval, min_interval_);
    }
}

int M07Manager::processByte(unsigned char byte) {
    if (!initialized_) return -1;
    
    switch (state_) {
        case State::IDLE:
            if (byte == FRAME_HEADER_0) {
                state_ = State::GOT_DE;
            }
            break;
            
        case State::GOT_DE:
            if (byte == FRAME_HEADER_1) {
                state_ = State::GOT_5B;
            } else {
                state_ = State::IDLE;
            }
            break;
            
        case State::GOT_5B:
            if (byte != 0) {
                handleWakeup();
            }
            state_ = State::IDLE;
            break;
            
        default:
            state_ = State::IDLE;
            break;
    }
    
    return 0;
}

bool M07Manager::init(const std::string& port, int baudrate) {
    if (initialized_) return true;
    
    state_ = State::IDLE;
    debug_mode_ = false;
    min_interval_ = 1.0;
    awake_flag_ = false;
    
    updateLastAwakeTime();
    
    serial_fd_ = openSerial(port, baudrate);
    if (serial_fd_ < 0) {
        return false;
    }
    
    initialized_ = true;
    
    printf("[M07] Initialized on %s\n", port.c_str());
    return true;
}

void M07Manager::deinit() {
    if (!initialized_) return;
    closeSerial();
    initialized_ = false;
    printf("[M07] Deinitialized\n");
}

bool M07Manager::isAwake() {
    if (!initialized_) return false;
    
    // 读取并处理串口数据
    unsigned char buf[256];
    int n = read(serial_fd_, buf, sizeof(buf));
    if (n > 0) {
        for (int i = 0; i < n; i++) {
            processByte(buf[i]);
        }
    }
    
    std::lock_guard<std::mutex> lock(mutex_);
    return awake_flag_;
}

void M07Manager::clearAwake() {
    std::lock_guard<std::mutex> lock(mutex_);
    awake_flag_ = false;
    state_ = State::IDLE;
}

void M07Manager::setDebug(bool enable) {
    debug_mode_ = enable;
    printf("[M07] Debug mode: %s\n", enable ? "ON" : "OFF");
}