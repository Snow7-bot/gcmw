/*************************************************************************************
@company: WHEELTEC (Dongguan) Co., Ltd
@product: NEW M2
@filename: m2n_com.cpp
@brief: M2N 串口通信协议实现
@version:       date:       author:            comments:
@v1.0           26-6-1      hj
*************************************************************************************/

#include "m2n_com.h"
#include <sys/stat.h>
#include <ctime>

// 单例实例
M2NManager& M2NManager::getInstance() {
    static M2NManager instance;
    return instance;
}

M2NManager::M2NManager()
    : control_fd_(-1)
    , audio_fd_(-1)
    , handshake_state_(HandshakeState::IDLE)
    , angle_(0)
    , awake_(false)
    , audio_file_(nullptr)
    , audio_thread_running_(false)
    , initialized_(false) {
}

M2NManager::~M2NManager() {
    deinit();
}

int M2NManager::openSerial(const std::string& port, int baudrate) {
    int fd = open(port.c_str(), O_RDWR | O_NOCTTY);
    if (fd < 0) {
        printf("[M2N] Failed to open %s: %s\n", port.c_str(), strerror(errno));
        return -1;
    }
    
    struct termios opt;
    memset(&opt, 0, sizeof(opt));
    tcgetattr(fd, &opt);
    
    speed_t speed;
    switch (baudrate) {
        case 9600: speed = B9600; break;
        case 19200: speed = B19200; break;
        case 38400: speed = B38400; break;
        case 57600: speed = B57600; break;
        case 115200: speed = B115200; break;
        default: speed = B115200; break;
    }
    cfsetispeed(&opt, speed);
    cfsetospeed(&opt, speed);
    
    opt.c_cflag &= ~CSIZE;
    opt.c_cflag |= CS8 | CLOCAL | CREAD;
    opt.c_cflag &= ~(PARENB | CSTOPB | CRTSCTS);
    opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    opt.c_iflag &= ~(IXON | IXOFF | IXANY | INLCR | ICRNL | IGNCR);
    opt.c_oflag &= ~OPOST;
    
    opt.c_cc[VMIN] = 0;
    opt.c_cc[VTIME] = 10;
    
    tcflush(fd, TCIFLUSH);
    tcsetattr(fd, TCSANOW, &opt);
    
    printf("[M2N] Opened %s\n", port.c_str());
    return fd;
}

void M2NManager::closeSerial() {
    if (control_fd_ >= 0) {
        close(control_fd_);
        control_fd_ = -1;
    }
    if (audio_fd_ >= 0 && audio_fd_ != control_fd_) {
        close(audio_fd_);
        audio_fd_ = -1;
    }
}

int M2NManager::serialWrite(int fd, const unsigned char* data, int len) {
    if (fd < 0) return -1;
    int written = write(fd, data, len);
    return (written == len) ? 0 : -1;
}

unsigned char M2NManager::calcChecksum(const unsigned char* data, int len) {
    unsigned char sum = 0;
    for (int i = 0; i < len; i++) sum += data[i];
    return (~sum) + 1;
}

int M2NManager::sendMessageWithId(uint16_t msg_id, uint8_t msg_type,
                                   const unsigned char* data, uint16_t data_len) {
    if (!initialized_) return -1;
    if (data_len > 10232) return -1;
    
    unsigned char buf[FRAME_BUF_SIZE];
    int idx = 0;
    
    buf[idx++] = FRAME_HEADER;
    buf[idx++] = USER_ID;
    buf[idx++] = msg_type;
    buf[idx++] = data_len & 0xFF;
    buf[idx++] = (data_len >> 8) & 0xFF;
    buf[idx++] = msg_id & 0xFF;
    buf[idx++] = (msg_id >> 8) & 0xFF;
    
    if (data && data_len > 0) {
        memcpy(buf + idx, data, data_len);
        idx += data_len;
    }
    buf[idx] = calcChecksum(buf, idx);
    return serialWrite(control_fd_, buf, idx + 1);
}

int M2NManager::sendMessage(uint8_t msg_type, const unsigned char* data, uint16_t data_len) {
    if (!initialized_) return -1;
    static uint16_t msg_id = 0;
    return sendMessageWithId(msg_id++, msg_type, data, data_len);
}

int M2NManager::sendAck(uint16_t msg_id, int code, const std::string& content) {
    char json[512];
    snprintf(json, sizeof(json), "{\"code\":%d,\"content\":\"%s\"}", code, content.c_str());
    return sendMessage(MSG_USER_DATA, (unsigned char*)json, strlen(json));
}

void M2NManager::saveAudio(const unsigned char* data, int len) {
    if (!config_.audio_port_save_file || len <= 0) return;
    
    if (!audio_file_) {
        char filename[256];
        const char* path = config_.audio_save_path.c_str();
        
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "mkdir -p %s", path);
        system(cmd);
        
        time_t now = time(nullptr);
        struct tm* tm = localtime(&now);
        if (tm && tm->tm_year + 1900 > 2000) {
            char ts[32];
            strftime(ts, sizeof(ts), "%Y%m%d_%H%M%S", tm);
            snprintf(filename, sizeof(filename), "%s/audio_%s.pcm", path, ts);
        } else {
            snprintf(filename, sizeof(filename), "%s/audio.pcm", path);
        }
        
        printf("[M2N] Creating audio file: %s\n", filename);
        audio_file_ = fopen(filename, "wb");
        if (!audio_file_) {
            printf("[M2N] ERROR: %s\n", strerror(errno));
            return;
        }
    }
    
    fwrite(data, 1, len, audio_file_);
    fflush(audio_file_);
}

void M2NManager::handleWakeup(const std::string& json_str) {
    if (json_str.empty()) {
        return;
    }
    
    cJSON* root = cJSON_Parse(json_str.c_str());
    if (!root) {
        return;
    }
    
    cJSON* type = cJSON_GetObjectItem(root, "type");
    if (type && cJSON_IsString(type) && strcmp(type->valuestring, "aiui_event") == 0) {
        cJSON* content = cJSON_GetObjectItem(root, "content");
        if (content) {
            cJSON* eventType = cJSON_GetObjectItem(content, "eventType");
            // 关键修改：eventType 是数字，不是字符串
            if (eventType && cJSON_IsNumber(eventType) && eventType->valueint == 4) {
                cJSON* info = cJSON_GetObjectItem(content, "info");
                if (info && cJSON_IsString(info) && info->valuestring) {
                    cJSON* info_json = cJSON_Parse(info->valuestring);
                    if (info_json) {
                        cJSON* ivw = cJSON_GetObjectItem(info_json, "ivw");
                        if (ivw) {
                            cJSON* angle = cJSON_GetObjectItem(ivw, "angle");
                            if (angle && cJSON_IsNumber(angle)) {
                                angle_ = angle->valueint;
                                awake_ = true;
                                printf("[M2N] Wakeup, angle=%d\n", angle_.load());
                                fflush(stdout);
                            }
                        }
                        cJSON_Delete(info_json);
                    }
                }
            }
        }
    }
    
    cJSON_Delete(root);
}

void M2NManager::handleControl(const std::string& json_str, uint16_t msg_id) {
    cJSON* root = cJSON_Parse(json_str.c_str());
    if (!root) {
        sendAck(msg_id, -1, "Invalid JSON");
        return;
    }
    
    cJSON* type = cJSON_GetObjectItem(root, "type");
    if (!type || !cJSON_IsString(type)) {
        sendAck(msg_id, -1, "Missing type");
        cJSON_Delete(root);
        return;
    }
    
    if (strcmp(type->valuestring, "manual_wakeup") == 0) {
        sendAck(msg_id, 0, "success");
        std::lock_guard<std::mutex> lock(mutex_);
        awake_ = true;
    }
    else if (strcmp(type->valuestring, "set_audio_port") == 0) {
        cJSON* content = cJSON_GetObjectItem(root, "content");
        if (content) {
            cJSON* enable = cJSON_GetObjectItem(content, "enable");
            if (enable && cJSON_IsNumber(enable)) {
                setAudioPortEnable(enable->valueint != 0);
                sendAck(msg_id, 0, "success");
            } else {
                sendAck(msg_id, -1, "Invalid enable");
            }
        } else {
            sendAck(msg_id, -1, "Missing content");
        }
    }
    else if (strcmp(type->valuestring, "get_audio_port_status") == 0) {
        char status[64];
        snprintf(status, sizeof(status), "{\"enable\":%d}", config_.enable_audio_port ? 1 : 0);
        sendAck(msg_id, 0, status);
    }
    else if (strcmp(type->valuestring, "version") == 0) {
        sendAck(msg_id, 0, "WHEELTEC mic v2.0");
    }
    else {
        char err[128];
        snprintf(err, sizeof(err), "Unknown type: %s", type->valuestring);
        sendAck(msg_id, -1, err);
    }
    
    cJSON_Delete(root);
}

void M2NManager::processMessage(const unsigned char* buf, int len) {
    if (len < 7) return;
    
    uint8_t msg_type = buf[2];
    int data_len = buf[3] | (buf[4] << 8);
    uint16_t msg_id = buf[5] | (buf[6] << 8);
    const unsigned char* data = buf + 7;
    
    // 确保 data_len 不会越界
    int actual_data_len = std::min(data_len, len - 7);
    if (actual_data_len <= 0) {
        return;
    }
    
    switch (msg_type) {
        case MSG_HANDSHAKE:
            if (actual_data_len >= 4 && data[0] == 0xA5) {
                std::lock_guard<std::mutex> lock(mutex_);
                if (handshake_state_ != HandshakeState::CONFIRMED) {
                    handshake_state_ = HandshakeState::CONFIRMED;
                    printf("[M2N] Handshake confirmed\n");
                    sendMessageWithId(msg_id, MSG_HANDSHAKE_ACK, 
                                      (const unsigned char*)"\xA5\x00\x00\x00", 4);
                }
            }
            break;
            
        case MSG_DEVICE: {
            std::string json(reinterpret_cast<const char*>(data), actual_data_len);
            // 打印完整 JSON（仅调试时使用）
            // if (actual_data_len > 0 && actual_data_len < 4096) {
            //     printf("[M2N] DEVICE full content: %s\n", json.c_str());
            // }
            handleWakeup(json);
            break;
        }
        
        case MSG_USER_DATA: {
            std::string json(reinterpret_cast<const char*>(data), actual_data_len);
            printf("[M2N] Received: %s\n", json.c_str());
            handleControl(json, msg_id);
            break;
        }
        
        case MSG_AUDIO_DATA:
            saveAudio(data, actual_data_len);
            break;
            
        default:
            printf("[M2N] Unknown type: 0x%02X\n", msg_type);
            break;
    }
}

int M2NManager::processByte(unsigned char byte) {
    if (!initialized_) return -1;
    
    static unsigned char buf[FRAME_BUF_SIZE];
    static int len = 0;
    
    buf[len++] = byte;
    
    if (len >= 2 && (buf[0] != FRAME_HEADER || buf[1] != USER_ID)) {
        memmove(buf, buf + 1, len - 1);
        len--;
        return 0;
    }
    
    if (len >= 7) {
        int data_len = buf[3] | (buf[4] << 8);
        int total_len = 7 + data_len + 1;
        
        if (total_len > FRAME_BUF_SIZE) {
            len = 0;
            return 0;
        }
        
        if (len == total_len) {
            unsigned char checksum = calcChecksum(buf, total_len - 1);
            if (checksum == buf[total_len - 1]) {
                processMessage(buf, total_len);
            } else {
                printf("[M2N] Checksum error\n");
            }
            len = 0;
        } else if (len > total_len) {
            len = 0;
        }
    }
    
    return 0;
}

void M2NManager::audioThreadFunc() {
    unsigned char read_buf[READ_BUF_SIZE];
    unsigned char frame_buf[FRAME_BUF_SIZE];
    int frame_len = 0;
    
    printf("[M2N] Audio thread started\n");
    
    while (audio_thread_running_ && config_.enable_audio_port) {
        if (audio_fd_ < 0) {
            usleep(100000);
            continue;
        }
        
        int n = read(audio_fd_, read_buf, sizeof(read_buf));
        if (n <= 0) {
            usleep(1000);
            continue;
        }
        
        for (int i = 0; i < n; i++) {
            frame_buf[frame_len++] = read_buf[i];
            
            while (frame_len >= 7) {
                int header_pos = -1;
                for (int j = 0; j <= frame_len - 7; j++) {
                    if (frame_buf[j] == FRAME_HEADER && frame_buf[j+1] == USER_ID) {
                        header_pos = j;
                        break;
                    }
                }
                
                if (header_pos == -1) {
                    frame_len = 0;
                    break;
                }
                
                if (header_pos > 0) {
                    memmove(frame_buf, frame_buf + header_pos, frame_len - header_pos);
                    frame_len -= header_pos;
                    continue;
                }
                
                int data_len = frame_buf[3] | (frame_buf[4] << 8);
                int total_len = 7 + data_len + 1;
                
                if (total_len < 8 || total_len > FRAME_BUF_SIZE) {
                    memmove(frame_buf, frame_buf + 1, frame_len - 1);
                    frame_len--;
                    continue;
                }
                
                if (frame_len < total_len) break;
                
                unsigned char checksum = calcChecksum(frame_buf, total_len - 1);
                if (checksum == frame_buf[total_len - 1]) {
                    if (frame_buf[2] == MSG_AUDIO_DATA) {
                        saveAudio(frame_buf + 7, data_len);
                    }
                }
                
                if (frame_len > total_len) {
                    memmove(frame_buf, frame_buf + total_len, frame_len - total_len);
                    frame_len -= total_len;
                } else {
                    frame_len = 0;
                }
            }
        }
        
        usleep(1000);
    }
    
    printf("[M2N] Audio thread stopped\n");
}

void M2NManager::handshakeThreadFunc() {
    sendMessageWithId(0, MSG_HANDSHAKE_ACK, (const unsigned char*)"\xA5\x00\x00\x00", 4);
    usleep(500000);
    
    std::lock_guard<std::mutex> lock(mutex_);
    if (handshake_state_ != HandshakeState::CONFIRMED) {
        handshake_state_ = HandshakeState::CONFIRMED;
        printf("[M2N] Handshake completed\n");
    }
}

bool M2NManager::init(const M2NConfig& config) {
    if (initialized_) return true;
    
    config_ = config;
    handshake_state_ = HandshakeState::IDLE;
    angle_ = 0;
    awake_ = false;
    audio_file_ = nullptr;
    
    control_fd_ = openSerial(config_.control_port, config_.baudrate);
    if (control_fd_ < 0) {
        printf("[M2N] Failed to open control port\n");
        return false;
    }
    
    if (config_.enable_audio_port) {
        audio_fd_ = openSerial(config_.audio_port, config_.baudrate);
        if (audio_fd_ >= 0) {
            audio_thread_running_ = true;
            audio_thread_ = std::make_unique<std::thread>(&M2NManager::audioThreadFunc, this);
        } else {
            printf("[M2N] Warning: Failed to open audio port\n");
            config_.enable_audio_port = false;
        }
    } else {
        audio_fd_ = -1;
    }
    
    initialized_ = true;
    
    handshake_thread_ = std::make_unique<std::thread>(&M2NManager::handshakeThreadFunc, this);
    
    printf("[M2N] Initialized (audio: %s)\n", config_.enable_audio_port ? "enabled" : "disabled");
    return true;
}

void M2NManager::deinit() {
    if (!initialized_) return;
    
    printf("[M2N] Deinitializing...\n");
    initialized_ = false;
    
    audio_thread_running_ = false;
    if (audio_thread_ && audio_thread_->joinable()) {
        audio_thread_->join();
    }
    if (handshake_thread_ && handshake_thread_->joinable()) {
        handshake_thread_->join();
    }
    
    if (audio_file_) {
        fclose(audio_file_);
        audio_file_ = nullptr;
    }
    
    closeSerial();
    
    printf("[M2N] Deinitialized\n");
}

bool M2NManager::isAwake() const {
    return awake_.load();
}

int M2NManager::getAngle() const {
    return angle_.load();
}

void M2NManager::clearAwake() {
    awake_ = false;
}

bool M2NManager::handshakeDone() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return handshake_state_ == HandshakeState::CONFIRMED;
}

bool M2NManager::setAudioPortEnable(bool enable) {
    if (!initialized_) return false;
    
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (enable && !config_.enable_audio_port) {
        config_.enable_audio_port = true;
        
        if (audio_fd_ < 0) {
            audio_fd_ = openSerial(config_.audio_port, config_.baudrate);
        }
        
        if (audio_fd_ >= 0) {
            tcflush(audio_fd_, TCIFLUSH);
            unsigned char discard[4096];
            while (read(audio_fd_, discard, sizeof(discard)) > 0);
            audio_thread_running_ = true;
            audio_thread_ = std::make_unique<std::thread>(&M2NManager::audioThreadFunc, this);
            printf("[M2N] Audio port enabled\n");
        } else {
            config_.enable_audio_port = false;
            return false;
        }
    } else if (!enable && config_.enable_audio_port) {
        config_.enable_audio_port = false;
        audio_thread_running_ = false;
        if (audio_thread_ && audio_thread_->joinable()) {
            audio_thread_->join();
        }
        if (audio_fd_ >= 0) {
            close(audio_fd_);
            audio_fd_ = -1;
        }
        if (audio_file_) {
            fclose(audio_file_);
            audio_file_ = nullptr;
        }
        printf("[M2N] Audio port disabled\n");
    }
    
    return true;
}

bool M2NManager::getAudioPortEnable() const {
    return config_.enable_audio_port;
}