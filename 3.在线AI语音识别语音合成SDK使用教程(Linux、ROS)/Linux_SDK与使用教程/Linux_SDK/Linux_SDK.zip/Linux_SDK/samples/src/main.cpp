#ifdef WIN32
    #include <windows.h>

    #define _HAS_STD_BYTE 0
    #define AIUI_SLEEP Sleep
#else
    #include <unistd.h>

    #define AIUI_SLEEP(x) usleep(x * 1000)
#endif

#undef AIUI_LIB_COMPILING

#include <cstring>
#include <fstream>
#include <iostream>
#include <queue>
#include <signal.h>
#include <condition_variable>

#include "com.h"
#include "aiui/AIUI_V2.h"
#include "aiui/PcmPlayer_C.h"
#include "json/json.h"
#include "utils/StreamNlpTtsHelper.h"
#include "utils/IatResultUtil.h"
#include "utils/Base64Util.h"
#include "PCMPlayer.h"
#include "AudioListenThread.h"

// 使用的AIUI服务版本：1（语义技能），2（语义技能 + 大模型），3（语义技能 + 大模型 + 极速交互）
#define AIUI_VER 3

#if AIUI_VER == 3
    // 是否使用语义后合成。当在AIUI平台应用配置页面打开"语音合成"开关时，需要打开该宏
    #define USE_POST_SEMANTIC_TTS
#endif

using namespace std;
using namespace aiui_va;
using namespace aiui_v2;

string gSyncSid;
string gVoiceCloneResId;
string awake_feedback = "请问有什么指示。";
int gPcmPlayerIndex = -1;
bool record_status = false;
bool initialized = false;
bool play_status;       //播放器状态
int player_mode = 1;    //0:aiui内置播放器，1:外置播放器（默认)

std::unique_ptr<AudioListenThread> audioListeningThread;
std::unique_ptr<PCMPlayer> player;           
bool is_wakeup_called = false;

std::thread tts_thread;             // TTS处理线程
bool tts_thread_running = false;    // TTS线程运行标志     
bool g_tts_cancelling = false;
bool g_allow_new_tts = true;        // 是否允许新的TTS
bool g_tts_is_playing = false;      // TTS是否正在播放
std::string g_current_tts_sid;      // 当前TTS的SID

IAIUIAgent* g_pAgent = nullptr;
SerialPort port;

//添加唤醒词列表(识别过滤)
const std::vector<std::string> wake_words = {
    "小微小微", 
    "小薇小薇", 
    "小V小V", 
    "小v小v",
    "你好小微",
    "你好小薇"
};

//等待tts播报
void waitForTtsComplete();

/*********************播放回调函数************************/
void onStarted()
{
    cout << "PcmPlayer, onStarted" << endl;
}

void onPaused()
{
    cout << "PcmPlayer, onPaused" << endl;
}

void onResumed()
{
    cout << "PcmPlayer, onResumed" << endl;
}

void onStopped()
{
    cout << "PcmPlayer, onStopped" << endl;
}

void onError(int error, const char* des)
{
    cout << "PcmPlayer, onError, error=" << error << ", des=" << des << endl;
}

void onProgress(int streamId, int progress, const char* audio, int len, bool isCompleted)
{
//    cout << "PcmPlayer, onProgress, streamId=" << streamId << ", progress=" << progress
//         << ", len=" << len << ", isCompleted=" << isCompleted << endl;
}

void startTTS(const string& text, const string& tag = "");
void cancelTTS(const std::string& sid = "");

/**
 * 外置播放器初始化
 */
int init_player()
{   
    player = std::make_unique<PCMPlayer>(16000,SND_PCM_FORMAT_S16_LE,1);
    if (!initialized) {
        if (player->init_alsa()) {
            initialized = true;
            return 0;
        } else {
            return -1;
        }
    }
}

/**
 * 开始录音接口
 */
void alsaStart()
{
    try {
        if (!audioListeningThread) {
            audioListeningThread = std::make_unique<AudioListenThread>(g_pAgent);
        }
        bool result = audioListeningThread->run();
        if (result) {
            record_status = true;
        } else {
            record_status = audioListeningThread->isRunning();
        }
    } catch (const std::exception& e) {
        std::cerr << "alsaStart error: " << e.what() << std::endl;
        record_status = false;
    }
}

/**
 * 停止录音接口
 */
void alsaStop()
{
    try {
        if (audioListeningThread) {
            audioListeningThread->stopRun();
            record_status = false;
        }
    } catch (const std::exception& e) {
        std::cerr << "alsaStop error: " << e.what() << std::endl;
        record_status = false;
    }
}

/**
 * 检查识别结果是否包含唤醒词
 */
bool containsWakeWord(const std::string& text) {
    std::string lowerText = text;
    // 转换为小写进行比较
    std::transform(lowerText.begin(), lowerText.end(), lowerText.begin(), 
                  [](unsigned char c){ return std::tolower(c); });
    
    for (const auto& word : wake_words) {
        std::string lowerWord = word;
        std::transform(lowerWord.begin(), lowerWord.end(), lowerWord.begin(), 
                      [](unsigned char c){ return std::tolower(c); });
        
        if (lowerText.find(lowerWord) != std::string::npos) {
            return true;
        }
    }
    return false;
}

// 从IAIUIListener派生自己的结果监听器
class DemoListener : public IAIUIListener
{
private:
    // 从StreamNlpTtsHelper::Listener派生流式合成监听器，用于监听大模型结果的合成
    class TtsHelperListener : public StreamNlpTtsHelper::Listener
    {
    public:
        void onText(const StreamNlpTtsHelper::OutTextSeg& textSeg) override {
            if (textSeg.isBegin() || textSeg.isEnd()) {
                if (aiui_pcm_player_get_state() != PCM_PLAYER_STATE_STARTED) {
                    aiui_pcm_player_start();
                }
                if (textSeg.isBegin()) {
                    aiui_pcm_player_clear();
                }
            }

            // 调用合成
            startTTS(textSeg.mText, textSeg.mTag);
        }

        void onFinish(const string& fullText) override {
            // 文本合成完成回调
            cout << "tts, fullText=" << fullText << endl;
        }

        void onTtsData(const Json::Value& bizParamJson, const char* audio, int len) override {
            const Json::Value& data = (bizParamJson["data"])[0];
            const Json::Value& content = (data["content"])[0];
            int dts = content["dts"].asInt();
            int progress = content["text_percent"].asInt();

            // 将合成数据写入播放器
            aiui_pcm_player_write(0, audio, len, dts, progress);
        }
    };

private:
    std::shared_ptr<StreamNlpTtsHelper> m_pTtsHelper;

    int mStreamTtsIndex{0};

public:
    DemoListener()
    {
        // 创建内置的pcm播放器，并初始化，设置回调，启动起来
        if (!player_mode){
            aiui_pcm_player_create();

            int count = aiui_pcm_player_get_output_device_count();
            for (int i = 0; i < count; i++) {
                std::cout << "pcm player index: " << i
                     << " device name: " << aiui_pcm_player_get_device_name(i) << std::endl;
            }
            std::cout << "user pcm player index: " << gPcmPlayerIndex << std::endl;

            int ret = aiui_pcm_player_init(2);
            if (ret == 0){
                initialized = true;
            }
            aiui_pcm_player_set_callbacks(
                onStarted, onPaused, onResumed, onStopped, onProgress, onError); 
            // aiui_pcm_player_start();   
        }
        else if (player_mode == 1){
            init_player();
        }

        std::shared_ptr<TtsHelperListener> listener = std::make_shared<TtsHelperListener>();
        m_pTtsHelper = std::make_shared<StreamNlpTtsHelper>(listener);
        m_pTtsHelper->setTextMinLimit(20);
    }

    ~DemoListener()
    {
        // 析构时销毁播放器，释放资源
        aiui_pcm_player_destroy();
    }

    /**
     * 重写onEvent方法，SDK通过回调该方法抛出各种事件，在这里针对事件做对应的处理。
     *
     * @param event
     */
    void onEvent(const IAIUIEvent& event) override
    {
        try {
            handleEvent(event);
        } catch (std::exception& e) {
            cout << e.what() << endl;
        }
    }

    // 是否输出更多信息
    bool mMoreDetails = true;

private:
    fstream mFs;

    // 当前合成sid
    string mCurTtsSid;

    // 当前识别sid
    string mCurIatSid;

    // 识别结果缓存
    string mIatTextBuffer;

    // 流式nlp的应答语缓存
    string mStreamNlpAnswerBuffer;

    // 当前收到了tts音频的长度
    int mTtsLen = 0;

    // 意图的数量
    int mIntentCnt = 0;

private:
    static void processIntentJson(Json::Value& params,
                           Json::Value& intentJson,
                           std::string& resultStr,
                           int eosRsltTime,
                           std::string& sid)
    {
        int rc = intentJson["rc"].asInt();

        Json::Value answerJson = intentJson["answer"];
        string answer = answerJson["text"].asString();

        // 正常nlp结果（AIUI通用语义模型返回的语义结果）
        cout << "----------------------------------" << endl;
        cout << "params: " << params.asString() << endl;
        cout << "nlp: " << resultStr << endl;
        cout << "eos_result=" << eosRsltTime << "ms" << endl;
        cout << "结果解析：" << endl;
        cout << "sid=" << sid << endl;
        cout << "text（请求文本）: " << intentJson["text"].asString() << endl;
        cout << "rc=" << rc << ", answer（应答语）: " << answer << endl;

        // 极速交互不支持主动合成，只有非主动交互才支持
#ifndef USE_RAPID_INTERACTION
        if (!answer.empty()) {
            startTTS(answer);
        }
#endif
    }

    void handleEvent(const IAIUIEvent& event)
    {
        switch (event.getEventType()) {
            // SDK状态
            case AIUIConstant::EVENT_STATE: {
                switch (event.getArg1()) {
                    case AIUIConstant::STATE_IDLE: {
                        // 空闲状态，即最初始的状态
                        cout << "EVENT_STATE: STATE_IDLE" << endl;
                    } break;

                    case AIUIConstant::STATE_READY: {
                        // 准备好状态（待唤醒），可以进行唤醒
                        cout << "EVENT_STATE: STATE_READY" << endl;
                    } break;

                    case AIUIConstant::STATE_WORKING: {
                        // 工作状态（即已唤醒状态），可以语音交互，也可以再次唤醒
                        cout << "EVENT_STATE: STATE_WORKING" << endl;
                    } break;
                }
            } break;

            // 唤醒事件
            case AIUIConstant::EVENT_WAKEUP: {
                //cout << "EVENT_WAKEUP: " << event.getInfo() << endl;

                // 唤醒时停止播放
                if (!player_mode) aiui_pcm_player_stop();
            } break;

            // 休眠事件，即一段时间无有效交互或者外部主动要求，SDK会自动进入STATE_READY状态
            case AIUIConstant::EVENT_SLEEP: {
                // arg1用来区分休眠类型，是自动休眠还是外部要求，可参考AIUIConstant.h中EVENT_SLEEP的注释
                cout << "EVENT_SLEEP: arg1=" << event.getArg1() << endl;
            } break;

            // VAD事件，如语音活动检测
            case AIUIConstant::EVENT_VAD: {
                // arg1为活动类型
                switch (event.getArg1()) {
                    case AIUIConstant::VAD_BOS_TIMEOUT: {
                        cout << "EVENT_VAD: VAD_BOS_TIMEOUT" << endl;
                        alsaStop();
                    } break;

                    // 检测到前端点，即开始说话
                    case AIUIConstant::VAD_BOS: {
                        cout << "EVENT_VAD: BOS" << endl;
                    } break;

                    // 检测到后端点，即说话结束
                    case AIUIConstant::VAD_EOS: {
                        cout << "EVENT_VAD: EOS" << endl;
                        alsaStop();
                    } break;

                    // 音量，arg2为音量级别（0-30）
                    case AIUIConstant::VAD_VOL: {
                        //cout << "EVENT_VAD: vol=" << event.getArg2() << endl;
                    } break;
                }
            } break;

            // 结果事件
            case AIUIConstant::EVENT_RESULT: {
                Json::Value bizParamJson;
                Json::Reader reader;

                if (!reader.parse(event.getInfo(), bizParamJson, false)) {
                    cout << "parse error! info=" << event.getInfo() << endl;
                    break;
                }

                Json::Value& data = (bizParamJson["data"])[0];
                Json::Value& params = data["params"];
                Json::Value& content = (data["content"])[0];

                string sub = params["sub"].asString();
                if (sub != "iat" && sub != "nlp" && sub != "tts" && sub != "cbm_tidy" && sub != "cbm_semantic") {
                    return;
                }

                // sid即唯一标识一次会话的id
                string sid = event.getData()->getString("sid", "");
                if (sub == "iat") {
                    if (sid != mCurIatSid) {
                        cout << "**********************************" << endl;
                        cout << "sid=" << sid << endl;

                        mCurIatSid = sid;

                        // 新的会话，清空之前识别缓存
                        mIatTextBuffer.clear();
                        mStreamNlpAnswerBuffer.clear();
                        m_pTtsHelper->clear();
                        mIntentCnt = 0;
                    }
                } else if (sub == "tts") {
                    if (sid != mCurTtsSid) {
                        cout << "**********************************" << endl;
                        cout << "sid=" << sid << endl;
                        mTtsLen = 0;
                        mCurTtsSid = sid;
                    }
                }

                Json::Value empty;
                string cnt_id = content.get("cnt_id", empty).asString();

                int dataLen = 0;

                // 注意：当buffer里存字符串时也不是以0结尾，当使用C语言时，转成字符串则需要自已在末尾加0
                const char* buffer = event.getData()->getBinary(cnt_id.c_str(), &dataLen);

                if (sub == "tts") {
                    // 语音合成结果，返回url或者pcm音频
                    //cout << "tts: " << content.toString() << endl;

#ifdef USE_POST_SEMANTIC_TTS //使用语义后合成
                    //多意图的语义后合成的tts信息,可以知晓当前的tts音频流是哪个意图的。
                    if (mIntentCnt > 1) {
                        int ttsOtherDataLen = 0;
                        const char* ttsOtherBuffer = event.getData()->getBinary("1", &ttsOtherDataLen);
                        string ttsOtherResultStr = string(ttsOtherBuffer, ttsOtherDataLen);
                        Json::Value ttsOtherResultJson;
                        if (reader.parse(ttsOtherResultStr, ttsOtherResultJson, false)) {
                            Json::Value metaTtsJson;
                            Json::Value textJson =
                                ttsOtherResultJson["cbm_meta"].get("text", metaTtsJson);
                            if (reader.parse(textJson.asString(), metaTtsJson, false)) {
                                int intentIndex = metaTtsJson["tts"]["intent"].asInt();
                                cout << "tts intent index: " << intentIndex
                                     << " , des: " << ttsOtherResultJson.asString().c_str() << endl;
                            }
                        }
                    }
#endif

                    Json::Value&& isUrl = content.get("url", empty);
                    if (isUrl.asString() == "1") {
                        // 云端返回的是url链接，可以用播放器播放
                        cout << "tts_url=" << string(buffer, dataLen) << endl;
                    } else {
                        // 云端返回的是pcm音频，分成一块块流式返回
                        int progress = 0;
                        int dts = content["dts"].asInt();
                        bool isFirstBlock = (dts == AIUIConstant::DTS_BLOCK_FIRST || dts == AIUIConstant::DTS_ONE_BLOCK);
                        bool isLastBlock = (dts == AIUIConstant::DTS_BLOCK_LAST || dts == AIUIConstant::DTS_ONE_BLOCK);
                        // 处理取消逻辑
                        if (g_tts_cancelling) {
                            // 检查是否是取消的会话
                            if (sid == mCurTtsSid || mCurTtsSid.empty()) {
                                if (isLastBlock) {
                                    //std::cout << "[TTS] 收到结束包，取消完成" << std::endl;
                                    g_tts_cancelling = false;
                                    mCurTtsSid.clear();
                                    g_current_tts_sid.clear();
                                    g_tts_is_playing = false;
                                    g_allow_new_tts = true;
                                }
                                return;
                            }
                        }
                        if (isFirstBlock) {
                            g_tts_is_playing = true;
                            g_allow_new_tts = false;
                            play_status = true;
                        }
                        
                        if (isLastBlock) {
                            g_tts_is_playing = false;
                            g_allow_new_tts = true;
                            play_status = false;
                            mCurTtsSid.clear();
                            g_current_tts_sid.clear();
                        }
                        std::string tag = event.getData()->getString("tag", "");
                        if (tag.find("stream_nlp_tts") == 0) {
                            // 流式语义应答的合成
                            m_pTtsHelper->onOriginTtsData(tag, bizParamJson, buffer, dataLen);
                        } else {
                            if (dts == AIUIConstant::DTS_BLOCK_FIRST || dts == AIUIConstant::DTS_ONE_BLOCK) {
                                // 只有碰到开始块，才开启播放器
                                if (aiui_pcm_player_get_state() != PCM_PLAYER_STATE_STARTED && player_mode == 0) {
                                    int ret = aiui_pcm_player_start();
                                    std::cout << "pcm start ret:" << ret << std::endl;
                                }
                                play_status = true;
                            }
                            if (!player_mode) aiui_pcm_player_write(0, buffer, dataLen, dts, progress);

                            /////////////////////////////////////////////////////////////////
                            // 播放音频（需要确保audio_data是PCM原始数据）
                            if (buffer && initialized) {
                                if (player_mode) player->play_pcm(buffer, dataLen, dts);
                            }
                            /////////////////////////////////////////////////////////////////

                            if (dts == AIUIConstant::DTS_BLOCK_LAST || dts == AIUIConstant::DTS_ONE_BLOCK) {
                                play_status = false;
                            }

                            // 若要保存合成音频，请打开以下开关
#if 0
                            // 音频开始
                            if (dts == AIUIConstant::DTS_BLOCK_FIRST ||
                                dts == AIUIConstant::DTS_ONE_BLOCK ||
                                /* 特殊情况:合成字符比较少时只有一包数据而且状态是２ */
                                (dts == AIUIConstant::DTS_BLOCK_LAST && 0 == mTtsLen)) {
                                mFs.open("tts.pcm", ios::binary | ios::out);
                            }

                            if (dataLen > 1) {
                                mFs.write(buffer, dataLen);
                            }

                            // 音频结束
                            if (dts == AIUIConstant::DTS_BLOCK_LAST || dts == AIUIConstant::DTS_ONE_BLOCK) {
                                mFs.close();
                            }
#endif
                        }
                    }
                } else if (sub == "iat") {
                    // 语音识别结果
                    string resultStr = string(buffer, dataLen);     // 注意：这里不能用string resultStr = buffer，因为buffer不一定以0结尾
                    Json::Value resultJson;
                    if (reader.parse(resultStr, resultJson, false)) {
                        Json::Value textJson = resultJson["text"];
                        bool isWpgs = false;
                        if (textJson.isMember("pgs")) {
                            isWpgs = true;
                        }

                        if (isWpgs) {
                            mIatTextBuffer = IatResultUtil::parsePgsIatText(textJson);
                        } else {
                            // 结果拼接起来
                            mIatTextBuffer.append(IatResultUtil::parseIatResult(textJson));
                        }

                        // 是否是该次会话最后一个识别结果
                        bool isLast = textJson["ls"].asBool();
                        if (isLast) {
                            //cout << "params: " << params.asString() << endl;
                            cout << "识别结果(online): " << mIatTextBuffer << std::endl;
                            if (record_status) alsaStop();
                            // 检查是否包含唤醒词
                            if (containsWakeWord(mIatTextBuffer)) {
                                mIatTextBuffer.clear();
                                std::cout << "检测到唤醒词，重新进入唤醒状态!" << std::endl;
                                
                                alsaStart();
                            }

                            mIatTextBuffer.clear();
                        }
                    }
                } else if (sub == "nlp") {
                    // 语义理解结果
                    // 注意：这里不能用string resultStr = buffer，因为buffer不一定以0结尾
                    string resultStr = string(buffer, dataLen);

                    // 从说完话到语义结果返回的时长
                    long eosRsltTime = event.getData()->getLong("eos_rslt", -1);

                    Json::Value resultJson;
                    if (reader.parse(resultStr, resultJson, false)) {
                        // 判断是否为有效结果
                        if (resultJson.isMember("intent") &&
                            resultJson["intent"].isMember("rc")) {
                            // AIUI v1的语义结果
                            Json::Value intentJson = resultJson["intent"];
                            processIntentJson(params, intentJson, resultStr, eosRsltTime, sid);
                        } else if (resultJson.isMember("nlp")) {
                            // AIUI v2的语义结果
                            Json::Value nlpJson = resultJson["nlp"];
                            string text = nlpJson["text"].asString();

                            if (text.find("{\"intent\":") == 0) {
                                // 通用语义结果
                                Json::Value textJson;
                                if (reader.parse(text, textJson, false)) {
                                    Json::Value intentJson = textJson["intent"];
                                    processIntentJson(params, intentJson, resultStr, eosRsltTime, sid);
                                }
                            } else {
                                // 大模型语义结果
                                // 流式nlp结果里面有seq和status字段
                                int seq = nlpJson["seq"].asInt();
                                int status = nlpJson["status"].asInt();

                                if (status == 0) {
                                    mStreamTtsIndex = 0;
                                }

                                /* 多意图取最后一次问题的结果进行tts合成 */
                                if (mIntentCnt > 1) {
                                    int currentIntentIndex = 0;
                                    Json::Value metaNlpJson;
                                    Json::Value textJson = resultJson["cbm_meta"].get("text", metaNlpJson);
                                    if (reader.parse(textJson.asString(), metaNlpJson, false)) {
                                        currentIntentIndex = metaNlpJson["nlp"]["intent"].asInt();
                                        if ((mIntentCnt - 1) != currentIntentIndex) {
                                            cout << "ignore nlp:" << resultStr << endl;
                                            return;
                                        }
                                    } else {
                                        cout << "ignore nlp:" << resultStr << endl;
                                        return;
                                    }
                                }

#ifndef USE_POST_SEMANTIC_TTS
                                // 如果使用应用的语义后合成不需要在调用下面的函数否则tts的播报会重复
                                m_pTtsHelper->addText(text, mStreamTtsIndex++, status);
#endif

                                cout << "----------------------------------" << endl;
                                cout << "params: " << params.asString() << endl;
                                cout << "nlp: " << resultStr << endl;

                                if (seq == 0) {
                                    long eosRsltTime = event.getData()->getLong("eos_rslt", -1);
                                    cout << "eos_result=" << eosRsltTime << "ms" << endl;
                                }

                                cout << "结果解析：" << endl;
                                cout << "sid=" << sid << endl;
                                cout << "seq=" << seq << ", status=" << status << ", answer（应答语）: " << text << endl;
                                cout << "fullAnswer=" << (mStreamNlpAnswerBuffer.append(text)) << endl;

                                if (status == 2) {
                                    mStreamNlpAnswerBuffer.clear();
                                }
                            }
                        } else {
                            // 无效结果，把原始结果打印出来
                            cout << "----------------------------------" << endl;
                            cout << "nlp: " << resultStr << endl;
                            cout << "sid=" << sid << endl;
                        }
                    }
                } else if (sub == "cbm_tidy") {
                    // 意图拆分的结果
                    string intentStr = string(buffer, dataLen); // 注意：这里不能用string resultStr = buffer，因为buffer不一定以0结尾
                    Json::Value tmpJson;
                    if (reader.parse(intentStr, tmpJson, false)) {
                        Json::Value intentTextJson = tmpJson["cbm_tidy"]["text"];
                        if (!intentTextJson.empty() &&
                            reader.parse(intentTextJson.asString(), tmpJson, false)) {
                            mIntentCnt = tmpJson["intent"].size();
                            cout << "cbm_intent_cnt: " << mIntentCnt
                                 << " text: " << tmpJson.toString() << endl;
                        }
                    }
                } else {
                    // 其他结果
                    string resultStr = string(buffer, dataLen);     // 注意：这里不能用string resultStr = buffer，因为buffer不一定以0结尾

                    cout << sub << ": " << event.getInfo() << endl << resultStr << endl;
                }
            } break;

            // 与CMD命令对应的返回结果，arg1为CMD类型，arg2为错误码
            case AIUIConstant::EVENT_CMD_RETURN: {
                if (AIUIConstant::CMD_BUILD_GRAMMAR == event.getArg1()) {
                    // 语法构建命令的结果
                    // 注：需要集成本地esr引擎才能构建语法
                    if (event.getArg2() == 0) {
                        cout << "build grammar success." << endl;
                    } else {
                        cout << "build grammar, error=" << event.getArg2() << ", des=" << event.getInfo() << endl;
                    }
                } else if (AIUIConstant::CMD_UPDATE_LOCAL_LEXICON == event.getArg1()) {
                    // 更新本地语法槽的结果
                    if (event.getArg2() == 0) {
                        cout << "update lexicon success" << endl;
                    } else {
                        cout << "update lexicon, error=" << event.getArg2() << "des=" << event.getInfo() << endl;
                    }
                } else if (AIUIConstant::CMD_CLONE_VOICE == event.getArg1()) {
                    //声音复刻
                    int dtype = event.getData()->getInt("sync_dtype", -1);
                    int retCode = event.getArg2();
                    string dataTypeStr;
                    if (dtype == AIUIConstant::VOICE_CLONE_REG) { //注册资源
                        dataTypeStr = "注册音频资源";
                    } else if (dtype == AIUIConstant::VOICE_CLONE_DEL) { //删除资源
                        dataTypeStr = "删除资源";
                    } else if (dtype == AIUIConstant::VOICE_CLONE_RES_QUERY) { //查询资源
                        dataTypeStr = "查询资源";
                    }

                    if (AIUIConstant::SUCCESS == retCode ) {
                        // 上传成功，会话的唯一id，用于反馈问题的日志索引字段，注意留存
                        // 注：上传成功立即生效
                        string sid = event.getData()->getString("sid", "");
                        // 获取上传调用时设置的自定义tag
                        string tag = event.getData()->getString("tag", "");
                        // 获取上传调用耗时，单位：ms
                        long timeSpent = event.getData()->getLong("time_spent", -1);
                        cout << "声音复刻" << dataTypeStr << "成功"
                             << "，耗时：" << timeSpent
                             << "ms, sid=" + sid + "，tag=" + tag;
                        if (dtype == AIUIConstant::VOICE_CLONE_REG) {
                            string resId = event.getData()->getString("res_id", "");
                            cout << "，res id = " << resId << endl;

                            //保存声音复刻的的res id
                            gVoiceCloneResId = resId;
                            fstream fs;
                            fs.open("./voice_clone_reg_id.txt", ios::binary | ios::out);
                            fs.write(resId.c_str(), resId.length());
                            fs.close();
                        } else if (dtype == AIUIConstant::VOICE_CLONE_RES_QUERY) {
                            string result = event.getData()->getString("result", "");
                            cout << ", result:" << endl;
                            cout << result << endl;
                        } else {
                            cout << endl;
                        }
                    } else {
                        string result = event.getData()->getString("result", "");
                        cout << "声音复刻" << dataTypeStr << "失败，错误码：" <<
                            retCode << " info:" << event.getInfo() << " result:" << result << endl;
                    }
                } else if (AIUIConstant::CMD_SYNC == event.getArg1()) {
                    // 数据同步的返回
                    int dtype = event.getData()->getInt("sync_dtype", -1);
                    int retCode = event.getArg2();

                #if AIUI_VER == 2 || AIUI_VER == 3
                    string dataTypeStr;
                    string text;

                    if (dtype == AIUIConstant::SYNC_DATA_UPLOAD) {
                        dataTypeStr = "上传实体";
                    } else if (dtype == AIUIConstant::SYNC_DATA_DELETE) {
                        dataTypeStr = "删除实体";
                    } else if (dtype == AIUIConstant::SYNC_DATA_DOWNLOAD) {
                        dataTypeStr = "下载实体";
                    } else if (dtype == AIUIConstant::SYNC_DATA_SEE_SAY) {
                        dataTypeStr = "所见即可说";
                    }

                    if (AIUIConstant::SUCCESS == retCode ) {
                        // 上传成功，会话的唯一id，用于反馈问题的日志索引字段，注意留存
                        // 注：上传成功立即生效
                        gSyncSid = event.getData()->getString("sid", "");
                        // 获取上传调用时设置的自定义tag
                        string tag = event.getData()->getString("tag", "");
                        // 获取上传调用耗时，单位：ms
                        long timeSpent = event.getData()->getLong("time_spent", -1);
                        cout << "同步" << dataTypeStr << "成功"
                             << "，耗时：" << timeSpent
                             << "ms, sid=" + gSyncSid + "，tag=" + tag;
                        if (dtype == AIUIConstant::SYNC_DATA_UPLOAD) {
                            cout << "，你可以试着说“打电话给刘德华“" << endl;
                        } else {
                            cout << endl;
                        }
                        // 实体内容
                        if (dtype == AIUIConstant::SYNC_DATA_DOWNLOAD) {
                            text = event.getData()->getString("text", "");
                            cout << "下载的实体内容:\n" << Base64Util::decode(text) << endl;
                        }
                    } else {
                        gSyncSid = "";
                        string result = event.getData()->getString("result", "");
                        cout << "同步" << dataTypeStr << "失败，错误码：" <<
                            retCode << " info:" << event.getInfo() << " result:" << result << endl;
                    }
                #else
                    if (dtype == AIUIConstant::SYNC_DATA_SCHEMA) {
                        if (AIUIConstant::SUCCESS == retCode) {
                            // 上传成功，记录上传会话的sid，以用于查询数据打包状态
                            // 注：上传成功并不表示数据打包成功，打包成功与否应以同步状态查询结果为准，数据只有打包成功后才能正常使用
                            gSyncSid = event.getData()->getString("sid", "");

                            // 获取上传调用时设置的自定义tag
                            string tag = event.getData()->getString("tag", "");

                            // 获取上传调用耗时，单位：ms
                            long timeSpent = event.getData()->getLong("time_spent", -1);

                            cout << "同步成功，"
                                 << "耗时：" << timeSpent
                                 << "ms, sid=" + gSyncSid + "，tag=" + tag +
                                        "，你可以试着说“打电话给刘德华“"
                                 << endl;
                        } else {
                            gSyncSid = "";
                            cout << "同步失败，错误码：" << retCode << endl;
                        }
                    }
                #endif
                }
            #if AIUI_VER == 1
                else if (AIUIConstant::CMD_QUERY_SYNC_STATUS == event.getArg1()) {
                    // 数据同步状态查询的返回
                    // 获取同步类型
                    int syncType = event.getData()->getInt("sync_dtype", -1);
                    if (AIUIConstant::SYNC_DATA_QUERY == syncType) {
                        // 若是同步数据查询，则获取查询结果，结果中error字段为0则表示上传数据打包成功，否则为错误码
                        string result = event.getData()->getString("result", "");

                        cout << "查询结果：" << result << endl;
                    }
                }
            #endif
            } break;

            // 开始录音事件
            case AIUIConstant::EVENT_START_RECORD: {
                cout << "EVENT_START_RECORD " << endl;
            } break;

            // 停止录音事件
            case AIUIConstant::EVENT_STOP_RECORD: {
                cout << "EVENT_STOP_RECORD " << endl;
            } break;

            // 出错事件
            case AIUIConstant::EVENT_ERROR: {
                // 打印错误码和描述信息(默认关闭大模型回复)
                std::string errorInfo = event.getInfo();
                if (errorInfo.find("nlp") != std::string::npos || 
                    errorInfo.find("NLP") != std::string::npos) {
                    // NLP 相关错误，忽略
                } else {
                    std::cout << "EVENT_ERROR: error=" << event.getArg1() << ", des=" << errorInfo << std::endl;
                    if (record_status) alsaStop();
                }
                //std::cout << "EVENT_ERROR: error=" << event.getArg1() << ", des=" << event.getInfo() << std::endl;
            } break;

            // 连接到服务器
            case AIUIConstant::EVENT_CONNECTED_TO_SERVER: {
                // 获取uid（为客户端在云端的唯一标识）并打印
                string uid = event.getData()->getString("uid", "");

                cout << "EVENT_CONNECTED_TO_SERVER, uid=" << uid << endl;
            } break;

            // 与服务器断开连接
            case AIUIConstant::EVENT_SERVER_DISCONNECTED: {
                cout << "EVENT_SERVER_DISCONNECTED " << endl;
            } break;

            //唤醒词操作的结果
            case AIUIConstant::EVENT_CAE_WAKEUP_WORD_RESULT: {
                int type = event.getArg1();
                int ret = event.getArg2();

                //保存唤醒词资源
                if (0 == ret && (type == AIUIConstant::CAE_GEN_WAKEUP_WORD ||
                                 type == AIUIConstant::CAE_ADD_WAKEUP_WORD)) {
                    int dataLen = 0;
                    const char* buffer = event.getData()->getBinary("data", &dataLen);
                    fstream fs;
                    fs.open("./wakeup_word_res.bin", ios::binary | ios::out);
                    fs.write(buffer, dataLen);
                    fs.close();
                }

                if (ret != 0) {
                    int dataLen = 0;
                    const char* buffer = event.getData()->getBinary("error_msg", &dataLen);
                    // 注意：这里不能用string errorMsg = buffer，因为buffer不一定以0结尾
                    string errorMsg = string(buffer, dataLen);
                    cout << "wakeup word operate fail, type = " << type << ", error code = " << ret
                         << ", error msg: " << errorMsg << endl;
                } else {
                    cout << "wakeup word operate success, type = " << type << endl;
                }

            } break;

            //唤醒音频事件
            case AIUIConstant::EVENT_CAE_WAKEUP_AUDIO: {
                int type = event.getArg1();
                //保存唤醒音频
                if (type == AIUIConstant::CAE_WAKEUP_AUDIO) {;
                    int dataLen = 0;
                    const char* buffer = event.getData()->getBinary("audio", &dataLen);
                    fstream fs;
                    fs.open("wakeup_audio.pcm", ios::binary | ios::out);
                    fs.write(buffer, dataLen);
                    fs.close();
                }
            } break;
        }
    }
};

DemoListener* g_pListener = nullptr; // NOLINT

#ifdef AIUI_ANDROID
    #define TEST_ROOT_DIR "/sdcard/AIUI/"
    #
    #ifdef TURING_UNIT_SUPPORT
        #define CFG_FILE_PATH "/sdcard/AIUI/cfg/turing.cfg"
    #else
        #define CFG_FILE_PATH "/sdcard/AIUI/cfg/aiui.cfg"
    #endif
    #
    #define TEST_AUDIO_PATH "/sdcard/AIUI/audio/test.pcm"
    #define LOG_DIR         "/sdcard/AIUI/log/"
    #define MSC_DIR         "/sdcard/AIUI/msc/"
    #define TEST_TTS_PATH   "/sdcard/AIUI/text/tts.txt"
    #define TEST_SEE_SAY_PATH "/sdcard/AIUI/text/see_say.txt"
    #define VOICE_CLONE_AUDIO_PATH "/sdcard/AIUI/audio/voice_clone_1ch24K16bit.pcm"
    #define VOICE_CLONE_RES_ID_PATH "/sdcard/AIUI/voice_clone_reg_id.txt"
    #define WAKE_WORD_TEXT_PATH "/sdcard/AIUI/wakeup_wake.txt"
#else
    #define TEST_ROOT_DIR "./AIUI/"
    #
    #ifdef TURING_UNIT_SUPPORT
        #define CFG_FILE_PATH "./AIUI/cfg/turing.cfg"
    #else
        #define CFG_FILE_PATH "./AIUI/cfg/aiui.cfg"
    #endif
    #
    #define TEST_AUDIO_PATH "./AIUI/audio/test.pcm"
    #define LOG_DIR         "./AIUI/log/"
    #define MSC_DIR         "./AIUI/msc/"
    #define TEST_TTS_PATH   "./AIUI/text/tts.txt"
    #define TEST_SEE_SAY_PATH "./AIUI/text/see_say.txt"
    #define VOICE_CLONE_AUDIO_PATH "./AIUI/audio/voice_clone_1ch24K16bit.pcm"
    #define VOICE_CLONE_RES_ID_PATH "./voice_clone_reg_id.txt"
    #define WAKE_WORD_TEXT_PATH "./AIUI/text/wakeup_wake.txt"
#endif

// 通讯录同步示例内容
string SYNC_CONTACT_CONTENT =       // NOLINT
    R"({"name":"刘得华", "phoneNumber":"13512345671"})" "\n"
    R"({"name":"张学诚", "phoneNumber":"13512345672"})" "\n"
    R"({"name":"张右兵", "phoneNumber":"13512345673"})" "\n"
    R"({"name":"吴羞波", "phoneNumber":"13512345674"})" "\n"
    R"({"name":"黎晓", "phoneNumber":"13512345675"})";

/**
 * 读取文件内容存到字符串。
 *
 * @param path
 * @return
 */
string readFileAsString(const string& path)
{
    ifstream t(path, ios_base::in | ios::binary);
    if (!t.is_open()) {
        std::cout << "Error open file: " << path << " fail." << endl;
        return "";
    }
    string str((istreambuf_iterator<char>(t)), istreambuf_iterator<char>());

    return str;
}

#define SEND_AIUIMESSAGE(cmd, arg1, arg2, params, data)                               \
    do {                                                                         \
        if (!g_pAgent) break;                                                       \
        IAIUIMessage* msg = IAIUIMessage::create(cmd, arg1, arg2, params, data); \
        g_pAgent->sendMessage(msg);                                                 \
        msg->destroy();                                                          \
    } while (false)

#define SEND_AIUIMESSAGE4(cmd, arg1, arg2, params) SEND_AIUIMESSAGE(cmd, arg1, arg2, params, nullptr)
#define SEND_AIUIMESSAGE3(cmd, arg1, arg2)              SEND_AIUIMESSAGE4(cmd, arg1, arg2, "")
#define SEND_AIUIMESSAGE2(cmd, arg1)                         SEND_AIUIMESSAGE3(cmd, arg1, 0)
#define SEND_AIUIMESSAGE1(cmd)                                    SEND_AIUIMESSAGE2(cmd, 0)

/**
 * 创建AIUIAgent对象。
 *
 * @param more
 * @param cfgPath
 */
void createAgent(bool more = true, const char* cfgPath = CFG_FILE_PATH)
{
    if (g_pAgent) {
        return;
    }

    string aiuiParams = readFileAsString(cfgPath);

    Json::Value paramJson;
    Json::Reader reader;
    if (reader.parse(aiuiParams, paramJson, false)) {
        if (more) {
            cout << paramJson.toString() << endl;
        }

        g_pListener->mMoreDetails = more;
        g_pAgent = IAIUIAgent::createAgent(paramJson.toString().c_str(), g_pListener);
    }

    if (!g_pAgent) {
        std::cout << string(cfgPath) << ", " << reader.getFormatedErrorMessages() << std::endl;
        return;
    }
}

/**
 * 销毁AIUIAgent对象。
 */
void destroyAgent()
{
    if (g_pAgent) {
        g_pAgent->destroy();
        g_pAgent = nullptr;
    }
}

/**
 * 唤醒AIUI。
 */
void wakeup()
{
    // 可以通过clear_data来控制是否要清除唤醒之前的数据（默认会清除），清除则唤醒之前的会话结果（tts除外）会被丢弃从而不再继续抛出
    SEND_AIUIMESSAGE4(AIUIConstant::CMD_WAKEUP, 0, 0, "clear_data=true");
}

/**
 * 重置唤醒，即回到待唤醒状态。
 */
void resetWakeup()
{
    SEND_AIUIMESSAGE1(AIUIConstant::CMD_RESET_WAKEUP);
}

/**
 * 开启AIUI服务，此接口是与stop()对应，调用stop()之后必须调用此接口才能继续与SDK交互。
 *
 * 注：AIUIAgent创建成功之后AIUI会自动开启，故若非调用过stop()则不需要调用start()。
 */
void start()
{
    SEND_AIUIMESSAGE1(AIUIConstant::CMD_START);
}

/**
 * 停止AIUI服务。
 */
void stop()
{
    SEND_AIUIMESSAGE1(AIUIConstant::CMD_STOP);
}

/**
 * 重置AIUI服务，相当于先调用stop()再调用start()。一般用不到。
 */
void resetAIUI()
{
    SEND_AIUIMESSAGE(AIUIConstant::CMD_RESET, 0, 0, "", nullptr);
}

/**
 * 从文件读音频写入SDK，即用文件数据模型实时录音数据。
 *
 * @param repeat
 */
void writeAudioFromLocal(bool repeat)
{
    if (!g_pAgent) {
        return;
    }

    ifstream testData(TEST_AUDIO_PATH, std::ios::in | std::ios::binary);

    if (testData.is_open()) {
        testData.seekg(0, std::ios::end);
        int total = testData.tellg();
        testData.seekg(0, std::ios::beg);

        char* audio = new char[total];
        testData.read(audio, total);
        testData.close();

        int offset = 0;
        int left = total;
        const int frameLen = 1280;
        char buff[frameLen];

        while (true) {
            if (left < frameLen) {
                if (repeat) {
                    offset = 0;
                    left = total;
                    continue;
                } else {
                    break;
                }
            }

            memset(buff, '\0', frameLen);
            memcpy(buff, audio + offset, frameLen);

            offset += frameLen;
            left -= frameLen;

            // frameData内存会在Message在内部处理完后自动release掉
            AIUIBuffer frameData = aiui_create_buffer_from_data(buff, frameLen);
            SEND_AIUIMESSAGE(AIUIConstant::CMD_WRITE, 0, 0, "data_type=audio,tag=audio-tag", frameData);

            // 必须暂停一会儿模拟人停顿，太快的话后端报错。1280字节16k采样16bit编码的pcm数据对应40ms时长
            AIUI_SLEEP(40);
        }

        // 音频写完后，要发CMD_STOP_WRITE停止写入消息
        SEND_AIUIMESSAGE4(AIUIConstant::CMD_STOP_WRITE, 0, 0, "data_type=audio");

        delete[] audio;
    } else {
        cout << "open file failed, path=" << TEST_AUDIO_PATH << endl;
    }

    cout << "write finish" << endl;
}

/**
 * 开启录音。
 */
void startRecordAudio()
{
    SEND_AIUIMESSAGE4(
        AIUIConstant::CMD_START_RECORD, 0, 0, "data_type=audio,pers_param={\"uid\":\"\"},tag=record-tag");
}

/**
 * 停止录音。
 */
void stopRecordAudio()
{
    SEND_AIUIMESSAGE1(AIUIConstant::CMD_STOP_RECORD);
}

/**
 * 写入文本进行交互。
 *
 * @param text 文本内容
 * @param needWakeup 是否需要唤醒
 */
void writeText(const string& text, bool needWakeup = true)
{
    AIUIBuffer textData = aiui_create_buffer_from_data(text.c_str(), text.length());

    if (needWakeup) {
        SEND_AIUIMESSAGE(AIUIConstant::CMD_WRITE, 0, 0, "data_type=text,pers_param={\"uid\":\"\"}", textData);
    } else {
        SEND_AIUIMESSAGE(AIUIConstant::CMD_WRITE, 0, 0, "data_type=text,need_wakeup=false", textData);
    }
}

/**
 * 取消语音合成
 */
void cancelTTS(const std::string& sid)
{ 
    if (!g_tts_is_playing && g_current_tts_sid.empty()) {
        return;
    }
    // 设置取消标志
    g_tts_cancelling = true;
    // 发送取消命令
    std::string params = "vcn=x4_lingxiaoying_em_v2";
    if (!sid.empty()) {
        params.append(",sid=").append(sid);
    }
    SEND_AIUIMESSAGE(AIUIConstant::CMD_TTS, AIUIConstant::CANCEL, 0, params.c_str(), nullptr);
}

/**
 * 等待TTS播放完成
 */
bool waitForTtsComplete(int timeout_ms = 5000) {
    auto start_time = std::chrono::steady_clock::now();
    while (g_tts_is_playing) {
        // 检查超时
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - start_time);
        if (elapsed.count() > timeout_ms) {
            cancelTTS();
            // 强制重置状态
            g_tts_is_playing = false;
            g_tts_cancelling = false;
            g_allow_new_tts = true;
            std::cout << "等待超时 " << timeout_ms << "ms)" << std::endl;
            return false;
        }
        // 检查TTS是否被取消
        if (!g_tts_is_playing || g_tts_cancelling) {
            std::cout << "TTS已被取消" << std::endl;
            return true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    return true;
}

/**
 * 测试语音合成，返回pcm数据。
 *
 * @param text
 */
// void startTTS(const string& text, const string& tag)
// {
//     AIUIBuffer textData = aiui_create_buffer_from_data(text.c_str(), text.length());
//     string params = "voice_name=x5_lingxiaoyue_flow";
//     if (!tag.empty()) {
//         params.append(",tag=").append(tag);
//     }

//     // 使用发音人x4_lingxiaoying_em_v2合成，也可以使用其他发音人
//     SEND_AIUIMESSAGE(AIUIConstant::CMD_TTS, AIUIConstant::START, 0, params.c_str(), textData);
// }

/**
 * 测试语音合成，返回pcm数据。
 *
 * @param text
 */
void startTTS(const std::string& text, const std::string& tag)
{
    if (initialized && player_mode) {
        player->prepare();
    }else {
        return;
    }
    // 检查是否允许新TTS
    if (!g_allow_new_tts) {
        std::cout << "[TTS] 当前不允许新的TTS" << std::endl;
        return;
    }
    
    // 如果已有TTS在播放，先取消
    if (g_tts_is_playing) {
        cancelTTS();
    }
    
    // 重置状态
    g_tts_is_playing = true;
    g_tts_cancelling = false;

    AIUIBuffer textData = aiui_create_buffer_from_data(text.c_str(), text.length());
    std::string params = "voice_name=x5_lingxiaoyue_flow";
    if (!tag.empty()) {
        params.append(",tag=").append(tag);
    }
    SEND_AIUIMESSAGE(AIUIConstant::CMD_TTS, AIUIConstant::START, 0, params.c_str(), textData);
}

/**
 * 播放唤醒反馈并等待完成
 */
void playAwakeFeedbackAndWait() {
    // 播放唤醒反馈
    startTTS(awake_feedback, "wake_feedback");
    waitForTtsComplete(3000);
}

#if AIUI_VER == 2 || AIUI_VER == 3
/**
 * AIUI登录操作，只有AIUI_V2才支持。
 */
void aiuiLogin()
{
    SEND_AIUIMESSAGE1(AIUIConstant::CMD_AIUI_LOGIN);
}
#endif

#if defined(__linux) || defined(__ANDROID__)
    #include <sys/socket.h>
    #include <net/if.h>
    #include <sys/ioctl.h>

/**
 * 获取mac地址。
 *
 * @param mac
 */
static void GenerateMACAddress(char* mac)
{
    // reference: https://stackoverflow.com/questions/1779715/how-to-get-mac-address-of-your-machine-using-a-c-program/35242525
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        return;
    };

    struct ifconf ifc{};
    char buf[1024];
    int success = 0;

    ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = buf;
    if (ioctl(sock, SIOCGIFCONF, &ifc) == -1) {
        return;
    }

    struct ifreq* it = ifc.ifc_req;
    const struct ifreq* const end = it + (ifc.ifc_len / sizeof(struct ifreq));
    struct ifreq ifr{};

    for (; it != end; ++it) {
        strcpy(ifr.ifr_name, it->ifr_name);
        if (ioctl(sock, SIOCGIFFLAGS, &ifr) == 0) {
            if (!(ifr.ifr_flags & IFF_LOOPBACK)) {    // don't count loopback
                if (ioctl(sock, SIOCGIFHWADDR, &ifr) == 0) {
                    success = 1;
                    break;
                }
            }
        } else {
            return;
        }
    }

    unsigned char mac_address[6];
    if (success) memcpy(mac_address, ifr.ifr_hwaddr.sa_data, 6);

    sprintf(mac,
            "%02x:%02x:%02x:%02x:%02x:%02x",
            mac_address[0],
            mac_address[1],
            mac_address[2],
            mac_address[3],
            mac_address[4],
            mac_address[5]);
    close(sock);
}
#elif defined(WIN32)
    #include <stdio.h>
    #include <IPHlpApi.h>
    #pragma comment(lib, "IPHLPAPI.lib")

static void GenerateMACAddress(char* mac)
{
    ULONG ulSize = 0;
    PIP_ADAPTER_INFO adapterInfo = NULL;
    PIP_ADAPTER_INFO adapterInfoTmp = NULL;

    GetAdaptersInfo(adapterInfo, &ulSize);

    if (0 == ulSize) {
        return;
    }

    adapterInfo = (PIP_ADAPTER_INFO)malloc(ulSize);

    if (adapterInfo == NULL) {
        return;
    }

    memset(adapterInfo, 0, ulSize);

    adapterInfoTmp = adapterInfo;

    GetAdaptersInfo(adapterInfo, &ulSize);

    while (adapterInfo) {
        _snprintf(mac,
                  64,
                  "%02x:%02x:%02x:%02x:%02x:%02x",
                  adapterInfo->Address[0],
                  adapterInfo->Address[1],
                  adapterInfo->Address[2],
                  adapterInfo->Address[3],
                  adapterInfo->Address[4],
                  adapterInfo->Address[5]);

        if (std::strcmp(adapterInfo->GatewayList.IpAddress.String, "0.0.0.0") != 0) break;

        adapterInfo = adapterInfo->Next;
    }

    free(adapterInfoTmp);

    adapterInfoTmp = NULL;
}
#endif

/**
 * 初始化设置。
 *
 * @param log
 */
static void initSetting(bool log = true)
{
    AIUISetting::setAIUIDir(TEST_ROOT_DIR);
    AIUISetting::setMscDir(MSC_DIR);
    AIUISetting::setNetLogLevel(log ? aiui_debug : aiui_none);

    char mac[64] = {0};
    GenerateMACAddress(mac);

    // 为每一个设备设置唯一对应的序列号SN（最好使用设备硬件信息(mac地址，设备序列号等）生成），以便正确统计装机量，
    // 避免刷机或者应用卸载重装导致装机量重复计数
    AIUISetting::setSystemInfo(AIUI_KEY_SERIAL_NUM, mac);

    // 6.6.xxxx.xxxx版本设置用户唯一标识uid（可选，AIUI后台服务需要，不设置则会使用上面的SN作为uid）
    // 5.6.xxxx.xxxx版本SDK不能也不需要设置uid
    // AIUISetting::setSystemInfo(AIUI_KEY_UID, "1234567890");
}

int main(int argc, char* argv[])
{
#ifdef WIN32
    system("chcp 65001 >nul");
    freopen("nul", "w", stderr);
#else
//    freopen("/dev/null", "w", stderr);
#endif

    if (argc > 1) {
        gPcmPlayerIndex = atoi(argv[1]);
    }

    g_pListener = new DemoListener;

    std::cout << "Version: " << getVersion() << std::endl;
    initSetting();

    cout << "createAgent" << endl;
    if (nullptr == g_pListener)
        g_pListener = new DemoListener;
    createAgent();

    if (!audioListeningThread) {
        audioListeningThread = std::make_unique<AudioListenThread>(g_pAgent);
    }

    std::cout << ">>>>>待唤醒，请用唤醒词进行唤醒！"<< std::endl;
    
    if (g_serial_port.initWithConfig()) {
        std::cout << ">>>>>成功打开麦克风设备串口，设备类型: " 
                  << getDeviceTypeName(getConfiguredDeviceType()) << std::endl;
    
        std::vector<unsigned char> buffer;
        while (true) {
            int n = g_serial_port.readData(buffer);
            if (n > 0) {
                for (auto byte : buffer) {
                    g_serial_port.dealWith(byte);
                }
            }
            
            // 唤醒后录音并进行识别
            if (g_serial_port.isAwake()){
                // 取消当前TTS
                if (g_tts_is_playing || play_status) {
                    cancelTTS();
                    std::this_thread::sleep_for(std::chrono::milliseconds(200));
                }
                
                // 停止录音
                if (record_status) {
                    alsaStop();
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                }
                
                // 唤醒AIUI
                if (!is_wakeup_called) {
                    wakeup();
                    is_wakeup_called = true;
                }
                
                // 同步播放唤醒反馈
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                startTTS(awake_feedback, "wake_feedback");
                waitForTtsComplete(5000);  // 等待完成
                
                // 等待声音完全结束
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
                
                // 重置设备并开始录音
                if (audioListeningThread) {
                    audioListeningThread->resetAudioDevice();
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                }
                
                alsaStart();
                g_serial_port.resetAwake();
            }
            
            usleep(10000); 
        }
    } else {
        std::cerr << ">>>>>无法打开麦克风设备串口" << std::endl;
    }

    if (tts_thread.joinable()) {
        tts_thread.join();
    }
    return 0;
}


