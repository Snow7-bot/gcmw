#/usr/bin/env bash

cur_path="$(dirname "$(readlink -f "$0")")"
cd $cur_path

mkdir build_arm64
cd build_arm64

cmake .. -DPLATFORM=arm64

cmake --build .