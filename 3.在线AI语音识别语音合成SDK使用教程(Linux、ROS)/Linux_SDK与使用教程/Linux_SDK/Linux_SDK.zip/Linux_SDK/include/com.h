#ifndef COM_TEST__H_
#define COM_TEST__H_

#pragma once

// ============================================================================
// 设备类型配置 - 修改下面的宏定义即可切换设备
// ============================================================================
// 可选值:
//   0 - M2 设备
//   1 - M2N 设备  
//   2 - M07 设备
// ============================================================================
#define SELECTED_DEVICE_TYPE 0

// 串口设备路径
#define MIC_SERIAL_PORT "/dev/wheeltec_mic"
// ============================================================================

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <string>
#include <vector>
#include <iostream>
#include <memory>
#include <functional>
#include <atomic>
#include <mutex>
#include "m2n_com.h"
#include "m07_com.h"

// 前向声明
class M2NManager;
class M07Manager;

// 设备类型枚举
enum class DeviceType {
    DEVICE_M2 = 0,
    DEVICE_M2N = 1,
    DEVICE_M07 = 2
};

// 获取编译时配置的设备类型
inline DeviceType getConfiguredDeviceType() {
    return static_cast<DeviceType>(SELECTED_DEVICE_TYPE);
}

// 获取设备类型名称
inline const char* getDeviceTypeName(DeviceType type) {
    switch (type) {
        case DeviceType::DEVICE_M2:  return "M2";
        case DeviceType::DEVICE_M2N: return "M2N";
        case DeviceType::DEVICE_M07: return "M07";
        default: return "Unknown";
    }
}

// 统一设备管理类
class SerialPort {
public:
    SerialPort();
    ~SerialPort();

    // 初始化/反初始化
    bool init(DeviceType type, const std::string& control_port = MIC_SERIAL_PORT);
    void deinit();
    
    // 设备类型初始化
    bool initWithConfig(const std::string& control_port = MIC_SERIAL_PORT) {
        return init(getConfiguredDeviceType(), control_port);
    }
    
    // 打开/关闭串口（兼容旧接口，仅M2使用）
    bool openPort(const std::string& uartname);
    void closePort();
    bool setOpt(int nSpeed, int nBits, unsigned char nEvent, int nStop);
    
    // 数据读写
    int readData(std::vector<unsigned char>& buffer);
    int writeData(const unsigned char* data, size_t length);
    
    // 数据处理接口（统一入口）
    int dealWith(unsigned char buffer);
    
    // M2旧版协议方法（保留兼容）
    short dataTrans(unsigned char data_high, unsigned char data_low);
    unsigned char checkSum(int count_num);
    
    // 状态获取
    bool isAwake() const;
    int getAngle() const;
    void resetAwake();
    
    // 设备切换
    bool switchDevice(DeviceType new_type, const std::string& port = "");
    
    // 获取当前设备类型
    DeviceType getDeviceType() const { return device_type_; }
    
    // 获取M2N管理器
    M2NManager& getM2NManager();
    M07Manager& getM07Manager();

private:
    // 各设备的处理函数
    int processM2Byte(unsigned char buffer);
    int processM2NByte(unsigned char buffer);
    int processM07Byte(unsigned char buffer);
    
    // M2旧版协议相关变量
    std::vector<unsigned char> receive_data_;
    int count_ = 0;
    int frame_len_ = 0;
    int msg_id_ = 0;
    
    // 统一状态变量
    DeviceType device_type_;
    std::atomic<bool> if_awake_;
    std::atomic<int> angle_int_;
    bool initialized_;
    
    // 串口文件描述符
    int control_fd_;
    int audio_fd_;
    
    // M2N配置
    M2NConfig m2n_config_;
    
    // 互斥锁
    mutable std::mutex mutex_;
    
    static constexpr unsigned char FRAME_HEADER = 0XA5;
    static constexpr unsigned char USER_ID = 0X01;
};

// 全局串口对象声明
extern SerialPort g_serial_port;

#endif /* COM_TEST_H_ */