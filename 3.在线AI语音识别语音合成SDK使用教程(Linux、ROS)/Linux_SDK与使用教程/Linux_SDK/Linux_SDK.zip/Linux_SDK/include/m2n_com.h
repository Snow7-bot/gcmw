/*************************************************************************************
@company: WHEELTEC (Dongguan) Co., Ltd
@product: NEW M2
@filename: m2n_com.h
@brief: M2N 串口通信协议头文件
@version:       date:       author:            comments:
@v1.0           26-6-1      hj
*************************************************************************************/

#ifndef M2N_COM_H
#define M2N_COM_H

#include <cstdint>
#include <string>
#include <memory>
#include <mutex>
#include <thread>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <sys/time.h>
#include <cjson/cJSON.h>

// M2N配置结构体
struct M2NConfig {
    std::string control_port = "/dev/wheeltec_mic";
    std::string audio_port = "/dev/wheeltec_mic_virtual";
    int baudrate = 115200;
    bool enable_audio_port = false;
    bool audio_port_save_file = false;
    std::string audio_save_path = "./audio/";
    
    M2NConfig() = default;
    M2NConfig(const std::string& ctrl_port) : control_port(ctrl_port) {}
};

// M2N 管理类
class M2NManager {
public:
    static M2NManager& getInstance();
    
    // 初始化/反初始化
    bool init(const M2NConfig& config = M2NConfig());
    void deinit();
    
    // 处理接收到的字节
    int processByte(unsigned char byte);
    
    // 状态查询
    bool isAwake() const;
    int getAngle() const;
    void clearAwake();
    bool handshakeDone() const;
    
    // 音频串口控制
    bool setAudioPortEnable(bool enable);
    bool getAudioPortEnable() const;
    
    // 发送消息
    int sendMessage(uint8_t msg_type, const unsigned char* data, uint16_t data_len);
    int sendAck(uint16_t msg_id, int code, const std::string& content);
    
    // 获取串口文件描述符
    int getControlFd() const { return control_fd_; }
    int getAudioFd() const { return audio_fd_; }
    
    // 是否已初始化
    bool isInitialized() const { return initialized_; }

private:
    M2NManager();
    ~M2NManager();
    M2NManager(const M2NManager&) = delete;
    M2NManager& operator=(const M2NManager&) = delete;
    
    // 内部函数
    int openSerial(const std::string& port, int baudrate);
    void closeSerial();
    int serialWrite(int fd, const unsigned char* data, int len);
    int sendMessageWithId(uint16_t msg_id, uint8_t msg_type, 
                          const unsigned char* data, uint16_t data_len);
    unsigned char calcChecksum(const unsigned char* data, int len);
    void processMessage(const unsigned char* buf, int len);
    void handleWakeup(const std::string& json_str);
    void handleControl(const std::string& json_str, uint16_t msg_id);
    void saveAudio(const unsigned char* data, int len);
    
    // 线程函数
    void audioThreadFunc();
    void handshakeThreadFunc();
    
    // 成员变量
    int control_fd_;
    int audio_fd_;
    M2NConfig config_;
    
    // 协议状态
    enum class HandshakeState {
        IDLE,
        SENT,
        CONFIRMED
    };
    HandshakeState handshake_state_;
    
    // 唤醒状态
    std::atomic<int> angle_;
    std::atomic<bool> awake_;
    
    // 音频文件
    FILE* audio_file_;
    
    // 线程
    std::unique_ptr<std::thread> audio_thread_;
    std::unique_ptr<std::thread> handshake_thread_;
    std::atomic<bool> audio_thread_running_;
    
    // 同步
    mutable std::mutex mutex_;
    std::atomic<bool> initialized_;
    
    // 协议常量
    static constexpr uint8_t FRAME_HEADER = 0xA5;
    static constexpr uint8_t USER_ID = 0x01;
    static constexpr uint8_t MSG_HANDSHAKE = 0x01;
    static constexpr uint8_t MSG_DEVICE = 0x04;
    static constexpr uint8_t MSG_USER_DATA = 0x05;
    static constexpr uint8_t MSG_AUDIO_DATA = 0x06;
    static constexpr uint8_t MSG_HANDSHAKE_ACK = 0xFF;
    
    static constexpr int FRAME_BUF_SIZE = 11528;
    static constexpr int READ_BUF_SIZE = 8192;
    static constexpr int JSON_BUF_SIZE = 4096;
};

#endif // M2N_COM_H