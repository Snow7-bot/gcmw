/*************************************************************************************
@company: WHEELTEC (Dongguan) Co., Ltd
@product: M07
@filename: m07_com.h
@brief: M07 串口通信协议头文件
@version:       date:       author:            comments:
@v1.0           26-6-1      hj                 
*************************************************************************************/

#ifndef M07_COM_H
#define M07_COM_H

#include <cstdint>
#include <string>
#include <atomic>
#include <mutex>
#include <cstdio>
#include <cstring>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <sys/time.h>

// M07 管理类
class M07Manager {
public:
    static M07Manager& getInstance();
    
    // 初始化/反初始化
    bool init(const std::string& port = "/dev/wheeltec_mic", int baudrate = 115200);
    void deinit();
    
    // 处理接收到的字节
    int processByte(unsigned char byte);
    
    // 状态查询
    bool isAwake();
    void clearAwake();
    
    // 获取串口文件描述符
    int getSerialFd() const { return serial_fd_; }
    
    // 调试模式
    void setDebug(bool enable);
    bool isDebug() const { return debug_mode_; }
    
    // 是否已初始化
    bool isInitialized() const { return initialized_; }

private:
    M07Manager();
    ~M07Manager();
    M07Manager(const M07Manager&) = delete;
    M07Manager& operator=(const M07Manager&) = delete;
    
    // 内部函数
    int openSerial(const std::string& port, int baudrate);
    void closeSerial();
    double getTimeSeconds();
    void updateLastAwakeTime();
    void handleWakeup();
    
    // 成员变量
    int serial_fd_;
    std::atomic<bool> initialized_;
    std::atomic<bool> debug_mode_;
    
    // 协议状态
    enum class State {
        IDLE,
        GOT_DE,
        GOT_5B
    };
    State state_;
    
    // 唤醒状态
    std::atomic<bool> awake_flag_;
    struct timeval last_awake_time_;
    double min_interval_;
    
    // 同步
    mutable std::mutex mutex_;
    
    // 协议常量
    static constexpr uint8_t FRAME_HEADER_0 = 0xDE;
    static constexpr uint8_t FRAME_HEADER_1 = 0x5B;
};

#endif // M07_COM_H